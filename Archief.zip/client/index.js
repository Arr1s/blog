import './index.css';
import '../server/layouts/base.js';


console.log('Hello, world!');
